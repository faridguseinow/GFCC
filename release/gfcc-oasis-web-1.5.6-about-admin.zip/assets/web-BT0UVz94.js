import{W as n}from"./index-BJ4Ex7QX.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
