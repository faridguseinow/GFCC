<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/api/_bootstrap.php';

gfcc_security_headers(true);
gfcc_start_session();

if (!gfcc_is_admin()) {
    header('Location: /admin/login.php', true, 302);
    exit;
}

$csrfToken = gfcc_csrf_token();
?>
<!doctype html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Статистика подключений — GFCC Oasis</title>
  <script>try{const a=localStorage.getItem('gfcc_admin_theme'),t=localStorage.getItem('theme');document.documentElement.dataset.theme=a||(t==='dark-theme'?'dark':'light')}catch(e){}</script>
  <link rel="stylesheet" href="/admin/style.css?v=1.5.6">
</head>
<body>
  <main class="admin-shell">
    <header class="admin-header">
      <div class="admin-brand">
        <img src="/icons/icon-192x192.png" alt="">
        <div>
          <p class="eyebrow">GFCC Oasis · Администратор</p>
          <h1>Клиентские карты</h1>
          <p class="admin-subtitle">Статистика подключений приложения</p>
        </div>
      </div>
      <div class="admin-header-actions">
        <button class="theme-button" type="button" data-theme-toggle aria-label="Переключить тему">◐</button>
        <form action="/admin/logout.php" method="post">
          <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
          <button class="secondary-button" type="submit">Выйти</button>
        </form>
      </div>
    </header>

    <button id="summary-card" class="summary-card" type="button" aria-expanded="false" aria-controls="clients-panel">
      <span class="summary-top"><span class="summary-label">Подключённые клиенты</span><span class="live-badge">В реальном времени</span></span>
      <strong id="connection-count">—</strong>
      <span class="summary-hint">Нажмите, чтобы открыть список · обновляется автоматически</span>
    </button>

    <section id="clients-panel" class="clients-panel" hidden>
      <div class="panel-header"><strong>Список подключений</strong><span>Обновление каждые 10 секунд</span></div>
      <div id="loading-state" class="state">Загрузка…</div>
      <div id="error-state" class="state error" hidden></div>
      <div id="empty-state" class="state" hidden>Подключений пока нет</div>
      <div id="table-wrap" class="table-wrap" hidden>
        <table>
          <thead>
            <tr>
              <th>Код клиента</th>
              <th>Клиент / организация</th>
              <th>База</th>
            </tr>
          </thead>
          <tbody id="clients-body"></tbody>
        </table>
        <nav class="pagination" aria-label="Страницы списка">
          <button id="prev-page" class="secondary-button" type="button">Назад</button>
          <span id="page-label"></span>
          <button id="next-page" class="secondary-button" type="button">Вперёд</button>
        </nav>
      </div>
    </section>
  </main>
  <script src="/admin/theme.js?v=1.5.6" defer></script>
  <script src="/admin/admin.js?v=1.5.6" defer></script>
</body>
</html>
